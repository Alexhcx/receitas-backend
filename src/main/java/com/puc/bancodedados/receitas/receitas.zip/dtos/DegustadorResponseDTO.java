package com.puc.bancodedados.receitas.dtos;

public record DegustadorResponseDTO(
        Long degustadorRg,
        String nomeEmpregado // Adicionado para conveniência
) {}

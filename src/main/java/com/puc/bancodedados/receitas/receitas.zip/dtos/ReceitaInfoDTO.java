package com.puc.bancodedados.receitas.dtos;

public record ReceitaInfoDTO(
        Long id,
        String nomeReceita
) {}

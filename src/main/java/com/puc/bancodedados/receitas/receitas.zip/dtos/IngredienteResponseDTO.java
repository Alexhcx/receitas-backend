package com.puc.bancodedados.receitas.dtos;

public record IngredienteResponseDTO(
        Long id,
        String nomeIngrediente,
        String descricaoIngrediente
) {}

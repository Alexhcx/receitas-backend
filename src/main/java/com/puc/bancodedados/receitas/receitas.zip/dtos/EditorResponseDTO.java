package com.puc.bancodedados.receitas.dtos;

public record EditorResponseDTO(
        Long editorRg,
        String nomeEmpregado // Adicionado para conveniência
) {}
